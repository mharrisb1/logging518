# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['logging518']

package_data = \
{'': ['*']}

install_requires = \
['toml>=0.10,<0.11']

setup_kwargs = {
    'name': 'logging518',
    'version': '0.1.0',
    'description': 'Custom logger config using pyproject.toml',
    'long_description': None,
    'author': 'Michael Harris',
    'author_email': 'michael.harrisru@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
