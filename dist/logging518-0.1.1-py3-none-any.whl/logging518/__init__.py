__version__ = "0.1.1"

from .logger518 import logger, log, debug_config, debug_file_path
